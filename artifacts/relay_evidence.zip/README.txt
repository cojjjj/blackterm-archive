BLACKTERM EVIDENCE BUNDLE

Three files were recovered from an abandoned relay.
One timestamp is impossible.
